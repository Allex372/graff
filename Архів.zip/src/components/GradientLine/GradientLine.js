import React from "react"

import * as styles from './gradientline.module.css';

const GradientLine = () => {
    return (
        <div className={styles.gradientLine} />
    )

}

export default GradientLine;